

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


CREATE TABLE IF NOT EXISTS `cart` (
  `Customer` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `Product` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `Quantity` int(5) NOT NULL,
  PRIMARY KEY (`Customer`,`Product`),
  KEY `Product` (`Product`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


INSERT INTO `cart` (`Customer`, `Product`, `Quantity`) VALUES
('suyashgulati', 'ENT-12', 1),
('suyash', 'NEW-4', 5),
('suyashgulati', 'ENT-1', 3),
('suyash', 'BIO-3', 5),
('suyashgulati', 'CHILD-1', 6),
('suyashgulati', 'NEW-1', 1),
('nimisha', 'NEW-2', 1),
('nimisha', 'ENT-7', 1),
('suyash', 'ENT-12', 1),
('suyashgulati', 'ENT-1222', 1),
('suyash', 'ENT-1', 1);



CREATE TABLE IF NOT EXISTS `products` (
  `PID` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `Title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Author` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `MRP` float NOT NULL,
  `Price` float NOT NULL,
  `Discount` int(11) DEFAULT NULL,
  `Available` int(11) NOT NULL,
  `Publisher` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Edition` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Category` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Description` text COLLATE utf8_unicode_ci,
  `Language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `page` int(5) DEFAULT NULL,
  `weight` int(4) DEFAULT '500',
  PRIMARY KEY (`PID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


CREATE TABLE IF NOT EXISTS `users` (
  `UserName` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`UserName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



INSERT INTO `users` (`UserName`, `Password`) VALUES
('suyash', 'gulati'),
('shivangi', 'gupta'),
('nimisha', 'sehgal'),
('avaleen', 'kaur'),
('ankita', 'negi'),
('astha', 'bhargav'),
('avani', 'khurana'),
('shikhar', 'gupta'),
('rakhi', 'gupta'),
('saurabh', 'saha'),
('suyashgulati', 's19'),
('a', 'a');

